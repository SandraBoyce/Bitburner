/** @param {NS} ns */
export async function main(ns) {
	hosts [
		'n00dles',
		'foodnstuff',
		'joesguns',
		'harakiri-sushi',
		'hong-fang-tea',
		'iron-gym',
		'max-hardware',
		'omega-net',
		'computek',
		'netlink',
		'catalyst',
		'silver-helix',
		'johnson-ortho',
		'aevum-police',
		'sigma-cosmetics',
		'zer0',
		'nectar-net',
		'neo-net',
		'crush-fitness',
		'rothman-uni',
		'phantasy',
		'the-hub'
	];

}