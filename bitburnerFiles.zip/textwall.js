/** @param {NS} ns */
export async function main(ns) {

}pt with 15 thread(s), pid 254 and args: ["rothman-uni"].

[first ~/]> run mhack.js rothman-uni -t 7

Running script with 7 thread(s), pid 255 and args: ["rothman-uni"].

[first ~/]> free

Total:       4.10TB

Used:        3.42TB (83.57%)

Available: 673.00GB

[first ~/]> run mgrow.js phantasy -t 76

Running script with 76 thread(s), pid 256 and args: ["phantasy"].

[first ~/]> run mweaken.js phantasy -t 15

Running script with 15 thread(s), pid 257 and args: ["phantasy"].

[first ~/]> run mhack.js phantasy -t 15

Running script with 15 thread(s), pid 258 and args: ["phantasy"].

[first ~/]> run mgrow.js the-hub -t 76

Running script with 76 thread(s), pid 259 and args: ["the-hub"].

[first ~/]> run mweaken.js the-hub -t 15

Running script with 15 thread(s), pid 260 and args: ["the-hub"].

[first ~/]> run mhack.js the-hub -t 7